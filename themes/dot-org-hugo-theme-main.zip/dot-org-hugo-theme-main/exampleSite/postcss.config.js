module.exports = {
    plugins: [
      require("autoprefixer")({
        overrideBrowserslist: ["> 0.5% in US"]
      })
    ]
  };

  

  
  